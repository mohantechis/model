from enum import Enum


class TrackerPriority(Enum):
    HIGH = 1
    NORMAL = 2
    LOW = 3
